SWEET CAKE — GABRIELA-INSPIRED EDITION

Tema: dramatic red, burgundy, gold, cream, romantic Latin-pop energy.
Struktur CRUD + login admin tetap dipertahankan.

Folder Laragon:
C:\laragon\www\Sweet_Cake_Gabriela_KATSEYE_

URL:
http://localhost/Sweet_Cake_Gabriela_KATSEYE_/

Database lokal:
toko_kue

Login admin:
username: admin
password: admin123
